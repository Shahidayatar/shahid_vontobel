"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEvaluationRoutes = createEvaluationRoutes;
const express_1 = require("express");
const evaluation_controller_1 = require("../controllers/evaluation.controller");
function createEvaluationRoutes(container) {
    const router = (0, express_1.Router)();
    const controller = (0, evaluation_controller_1.createEvaluationController)(container);
    router.post("/evaluate", controller.evaluate);
    return router;
}
