"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProvisioningRepository = void 0;
class ProvisioningRepository {
    statuses = new Map();
    save(status) {
        this.statuses.set(status.agentId, status);
        return status;
    }
    findByAgentId(agentId) {
        return this.statuses.get(agentId);
    }
}
exports.ProvisioningRepository = ProvisioningRepository;
