"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createChatRoutes = createChatRoutes;
const express_1 = require("express");
const chat_controller_1 = require("../controllers/chat.controller");
function createChatRoutes(container) {
    const router = (0, express_1.Router)();
    const controller = (0, chat_controller_1.createChatController)(container);
    router.post("/chat", controller.chat);
    return router;
}
