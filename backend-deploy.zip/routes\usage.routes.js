"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUsageRoutes = createUsageRoutes;
const express_1 = require("express");
const usage_controller_1 = require("../controllers/usage.controller");
function createUsageRoutes(container) {
    const router = (0, express_1.Router)();
    const controller = (0, usage_controller_1.createUsageController)(container);
    router.get("/usage/:tenantId", controller.getUsage);
    return router;
}
