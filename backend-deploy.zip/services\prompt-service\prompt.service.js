"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptService = void 0;
const crypto_1 = require("crypto");
class PromptService {
    agentRepository;
    promptRepository;
    constructor(agentRepository, promptRepository) {
        this.agentRepository = agentRepository;
        this.promptRepository = promptRepository;
    }
    createPrompt(agentId, tenantId, systemPrompt, createdBy) {
        const agent = this.agentRepository.findById(agentId);
        if (!agent || agent.tenantId !== tenantId) {
            throw new Error("Agent not found for tenant");
        }
        this.promptRepository.deactivateExisting(agentId, tenantId);
        const version = this.promptRepository.listByAgent(agentId, tenantId).length + 1;
        const prompt = {
            id: (0, crypto_1.randomUUID)(),
            agentId,
            tenantId,
            version,
            systemPrompt,
            createdBy,
            createdAt: new Date().toISOString(),
            isActive: true
        };
        this.promptRepository.save(prompt);
        return prompt;
    }
    listPrompts(agentId, tenantId) {
        return this.promptRepository.listByAgent(agentId, tenantId);
    }
}
exports.PromptService = PromptService;
