"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createUsageController = createUsageController;
function createUsageController(container) {
    return {
        getUsage: (req, res) => {
            const tenantId = String(req.params.tenantId);
            return res.json(container.usageService.getUsageByTenant(tenantId));
        }
    };
}
