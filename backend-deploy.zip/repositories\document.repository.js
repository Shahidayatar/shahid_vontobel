"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DocumentRepository = void 0;
class DocumentRepository {
    documents = new Map();
    chunks = new Map();
    saveDocument(document) {
        this.documents.set(document.id, document);
        return document;
    }
    findDocumentById(id) {
        return this.documents.get(id);
    }
    listDocumentsByAgent(agentId, tenantId) {
        return Array.from(this.documents.values()).filter((document) => document.agentId === agentId && document.tenantId === tenantId);
    }
    saveChunk(chunk) {
        this.chunks.set(chunk.id, chunk);
        return chunk;
    }
    listChunksByAgent(agentId, tenantId) {
        return Array.from(this.chunks.values()).filter((chunk) => chunk.agentId === agentId && chunk.tenantId === tenantId);
    }
    deleteChunksByDocument(documentId) {
        for (const [chunkId, chunk] of this.chunks.entries()) {
            if (chunk.documentId === documentId) {
                this.chunks.delete(chunkId);
            }
        }
    }
}
exports.DocumentRepository = DocumentRepository;
