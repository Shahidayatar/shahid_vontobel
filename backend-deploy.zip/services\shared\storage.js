"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.storeLocalBlob = storeLocalBlob;
const promises_1 = require("fs/promises");
const path_1 = require("path");
async function storeLocalBlob(baseDir, relativePath, fileName, buffer, mimeType) {
    const finalPath = (0, path_1.join)(baseDir, relativePath, fileName);
    await (0, promises_1.mkdir)((0, path_1.dirname)(finalPath), { recursive: true });
    await (0, promises_1.writeFile)(finalPath, buffer);
    return {
        path: finalPath,
        fileName,
        mimeType,
        size: buffer.byteLength
    };
}
