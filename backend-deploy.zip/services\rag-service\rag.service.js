"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.RagService = void 0;
const crypto_1 = require("crypto");
const promises_1 = require("fs/promises");
const path_1 = require("path");
const text_1 = require("../shared/text");
const embeddings_1 = require("../shared/embeddings");
const storage_1 = require("../shared/storage");
class RagService {
    agentRepository;
    documentRepository;
    usageRepository;
    azureClients;
    storageRoot = (0, path_1.join)(process.cwd(), "data", "uploads");
    constructor(agentRepository, documentRepository, usageRepository, azureClients) {
        this.agentRepository = agentRepository;
        this.documentRepository = documentRepository;
        this.usageRepository = usageRepository;
        this.azureClients = azureClients;
    }
    async uploadDocument(input) {
        const agent = this.agentRepository.findById(input.agentId);
        if (!agent || agent.tenantId !== input.tenantId) {
            throw new Error("Agent not found for tenant");
        }
        const blob = await (0, storage_1.storeLocalBlob)(this.storageRoot, `${input.tenantId}/${input.agentId}`, `${(0, crypto_1.randomUUID)()}-${input.fileName}`, input.content, input.mimeType);
        if (this.azureClients?.blob) {
            const containerName = agent.resourcePlan?.storageContainerName ?? `${input.agentId.slice(0, 12)}docs`;
            const containerClient = await this.azureClients.blob.ensureContainer(containerName);
            const blobClient = containerClient.getBlockBlobClient(blob.fileName);
            await blobClient.uploadData(input.content, {
                blobHTTPHeaders: { blobContentType: input.mimeType }
            });
        }
        const text = (0, text_1.normalizeText)(input.content.toString("utf8"));
        const document = {
            id: (0, crypto_1.randomUUID)(),
            agentId: input.agentId,
            tenantId: input.tenantId,
            fileName: input.fileName,
            mimeType: input.mimeType,
            storagePath: blob.path,
            textLength: text.length,
            status: "uploaded",
            createdAt: new Date().toISOString()
        };
        this.documentRepository.saveDocument(document);
        this.usageRepository.save({
            id: (0, crypto_1.randomUUID)(),
            requestId: (0, crypto_1.randomUUID)(),
            tenantId: input.tenantId,
            agentId: input.agentId,
            operation: "document-upload",
            model: "n/a",
            inputTokens: (0, text_1.estimateTokens)(text),
            outputTokens: 0,
            estimatedCostUsd: 0,
            createdAt: new Date().toISOString()
        });
        return document;
    }
    async indexDocuments(agentId, tenantId) {
        const agent = this.agentRepository.findById(agentId);
        if (!agent || agent.tenantId !== tenantId) {
            throw new Error("Agent not found for tenant");
        }
        const documents = this.documentRepository.listDocumentsByAgent(agentId, tenantId).filter((document) => document.status !== "indexed");
        const indexedChunks = [];
        const searchIndexName = agent.resourcePlan?.searchIndexName ?? `${agentId.slice(0, 12)}-chunks`;
        if (this.azureClients?.search) {
            await this.azureClients.search.ensureIndex(searchIndexName, 1536);
        }
        for (const document of documents) {
            const content = (0, text_1.normalizeText)(await this.loadDocumentText(document));
            const pieces = (0, text_1.chunkText)(content);
            for (const [chunkIndex, piece] of pieces.entries()) {
                const vector = await this.createVector(piece);
                const chunk = {
                    id: (0, crypto_1.randomUUID)(),
                    agentId,
                    tenantId,
                    documentId: document.id,
                    fileName: document.fileName,
                    chunkIndex,
                    text: piece,
                    vector,
                    createdAt: new Date().toISOString()
                };
                this.documentRepository.saveChunk(chunk);
                indexedChunks.push(chunk);
                if (this.azureClients?.search) {
                    const searchClient = this.azureClients.search.getSearchClient(searchIndexName);
                    await searchClient.mergeOrUploadDocuments([{
                            id: chunk.id,
                            tenantId: chunk.tenantId,
                            agentId: chunk.agentId,
                            documentId: chunk.documentId,
                            fileName: chunk.fileName,
                            chunkIndex: chunk.chunkIndex,
                            content: chunk.text,
                            contentVector: chunk.vector
                        }]);
                }
            }
            this.documentRepository.saveDocument({
                ...document,
                status: "indexed",
                indexedAt: new Date().toISOString()
            });
        }
        return indexedChunks;
    }
    listChunks(agentId, tenantId) {
        return this.documentRepository.listChunksByAgent(agentId, tenantId);
    }
    async loadDocumentText(document) {
        const buffer = await (0, promises_1.readFile)(document.storagePath);
        return (0, text_1.normalizeText)(buffer.toString("utf8"));
    }
    async createVector(text) {
        if (this.azureClients?.openAi) {
            const openAiClient = await this.azureClients.openAi.getClient();
            const embeddings = await openAiClient.getEmbeddings(this.azureClients.openAi.embeddingDeployment, [text]);
            return embeddings.data[0]?.embedding;
        }
        return (0, embeddings_1.createEmbedding)(text);
    }
}
exports.RagService = RagService;
