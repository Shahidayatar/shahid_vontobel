"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createEvaluationController = createEvaluationController;
function createEvaluationController(container) {
    return {
        evaluate: (req, res) => {
            return res.json(container.evaluationService.evaluate(req.body));
        }
    };
}
