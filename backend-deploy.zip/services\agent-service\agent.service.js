"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentService = void 0;
const crypto_1 = require("crypto");
class AgentService {
    agentRepository;
    promptRepository;
    constructor(agentRepository, promptRepository) {
        this.agentRepository = agentRepository;
        this.promptRepository = promptRepository;
    }
    createAgent(input) {
        const now = new Date().toISOString();
        const agent = {
            id: (0, crypto_1.randomUUID)(),
            tenantId: input.tenantId,
            name: input.name,
            description: input.description,
            model: input.model,
            systemPrompt: input.systemPrompt,
            dataSources: input.dataSources ?? [],
            isProvisioned: false,
            createdAt: now,
            updatedAt: now
        };
        this.agentRepository.save(agent);
        this.promptRepository.save({
            id: (0, crypto_1.randomUUID)(),
            agentId: agent.id,
            tenantId: agent.tenantId,
            version: 1,
            systemPrompt: agent.systemPrompt,
            createdBy: "system",
            createdAt: now,
            isActive: true
        });
        return agent;
    }
    listAgents(tenantId) {
        return this.agentRepository.listByTenant(tenantId);
    }
    getAgent(tenantId, agentId) {
        const agent = this.agentRepository.findById(agentId);
        if (!agent || agent.tenantId !== tenantId) {
            return undefined;
        }
        return agent;
    }
    updateAgent(tenantId, agentId, input) {
        const current = this.getAgent(tenantId, agentId);
        if (!current) {
            return undefined;
        }
        const updated = {
            ...current,
            ...input,
            dataSources: input.dataSources ?? current.dataSources,
            updatedAt: new Date().toISOString()
        };
        this.agentRepository.save(updated);
        if (input.systemPrompt) {
            this.promptRepository.deactivateExisting(updated.id, updated.tenantId);
            this.promptRepository.save({
                id: (0, crypto_1.randomUUID)(),
                agentId: updated.id,
                tenantId: updated.tenantId,
                version: this.promptRepository.listByAgent(updated.id, updated.tenantId).length + 1,
                systemPrompt: input.systemPrompt,
                createdBy: "system",
                createdAt: updated.updatedAt,
                isActive: true
            });
        }
        return updated;
    }
    deleteAgent(tenantId, agentId) {
        const current = this.getAgent(tenantId, agentId);
        if (!current) {
            return false;
        }
        return this.agentRepository.delete(agentId);
    }
    markProvisioned(agentId, resourcePlan, status) {
        const agent = this.agentRepository.findById(agentId);
        if (!agent) {
            return undefined;
        }
        const updated = {
            ...agent,
            isProvisioned: status === "succeeded",
            provisioningStatus: status,
            resourcePlan,
            updatedAt: new Date().toISOString()
        };
        this.agentRepository.save(updated);
        return updated;
    }
}
exports.AgentService = AgentService;
