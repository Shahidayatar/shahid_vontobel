"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.createRagRoutes = createRagRoutes;
const express_1 = require("express");
const multer_1 = __importDefault(require("multer"));
const rag_controller_1 = require("../controllers/rag.controller");
const upload = (0, multer_1.default)({ storage: multer_1.default.memoryStorage() });
function createRagRoutes(container) {
    const router = (0, express_1.Router)();
    const controller = (0, rag_controller_1.createRagController)(container);
    router.post("/documents/upload", upload.single("file"), controller.uploadDocument);
    router.post("/documents/:agentId/index", controller.indexDocuments);
    return router;
}
