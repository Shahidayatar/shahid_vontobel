"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.buildApp = buildApp;
const express_1 = __importDefault(require("express"));
const cors_1 = __importDefault(require("cors"));
const helmet_1 = __importDefault(require("helmet"));
const morgan_1 = __importDefault(require("morgan"));
const env_1 = require("./config/env");
const logger_1 = require("./config/logger");
const auth_1 = require("./middleware/auth");
const error_handler_1 = require("./middleware/error-handler");
const request_context_1 = require("./middleware/request-context");
const routes_1 = require("./routes");
const container_1 = require("./container");
function buildApp() {
    const app = (0, express_1.default)();
    const container = (0, container_1.createContainer)();
    app.use((0, helmet_1.default)());
    app.use((0, cors_1.default)());
    app.use(express_1.default.json({ limit: "2mb" }));
    app.use(express_1.default.urlencoded({ extended: true }));
    app.use(request_context_1.requestContextMiddleware);
    app.use(auth_1.authMiddleware);
    app.use((0, morgan_1.default)("combined"));
    app.get("/healthz", (_req, res) => {
        res.json({ status: "ok", app: env_1.env.APP_NAME, timestamp: new Date().toISOString() });
    });
    (0, routes_1.registerRoutes)(app, container);
    app.use(error_handler_1.errorHandler);
    logger_1.logger.info("Application bootstrapped", { app: env_1.env.APP_NAME });
    return app;
}
