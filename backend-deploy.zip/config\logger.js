"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.logger = void 0;
function write(level, message, context = {}) {
    const entry = {
        level,
        message,
        timestamp: new Date().toISOString(),
        ...context
    };
    const serialized = JSON.stringify(entry);
    if (level === "error") {
        console.error(serialized);
        return;
    }
    if (level === "warn") {
        console.warn(serialized);
        return;
    }
    console.log(serialized);
}
exports.logger = {
    debug(message, context) {
        write("debug", message, context);
    },
    info(message, context) {
        write("info", message, context);
    },
    warn(message, context) {
        write("warn", message, context);
    },
    error(message, context) {
        write("error", message, context);
    }
};
