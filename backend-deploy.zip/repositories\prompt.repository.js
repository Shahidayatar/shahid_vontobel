"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.PromptRepository = void 0;
class PromptRepository {
    versions = new Map();
    save(version) {
        this.versions.set(version.id, version);
        return version;
    }
    listByAgent(agentId, tenantId) {
        return Array.from(this.versions.values())
            .filter((version) => version.agentId === agentId && version.tenantId === tenantId)
            .sort((left, right) => right.version - left.version);
    }
    findActiveByAgent(agentId, tenantId) {
        return this.listByAgent(agentId, tenantId).find((version) => version.isActive);
    }
    deactivateExisting(agentId, tenantId) {
        for (const [id, version] of this.versions.entries()) {
            if (version.agentId === agentId && version.tenantId === tenantId) {
                this.versions.set(id, { ...version, isActive: false });
            }
        }
    }
}
exports.PromptRepository = PromptRepository;
