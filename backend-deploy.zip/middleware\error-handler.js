"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.errorHandler = errorHandler;
const logger_1 = require("../config/logger");
function errorHandler(error, req, res, _next) {
    const message = error instanceof Error ? error.message : "Unexpected error";
    logger_1.logger.error("Request failed", {
        requestId: req.requestId,
        error: message
    });
    res.status(500).json({
        error: "InternalServerError",
        message,
        requestId: req.requestId
    });
}
