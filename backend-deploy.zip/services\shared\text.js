"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.normalizeText = normalizeText;
exports.chunkText = chunkText;
exports.estimateTokens = estimateTokens;
exports.tokenize = tokenize;
function normalizeText(text) {
    return text.replace(/\s+/g, " ").trim();
}
function chunkText(text, chunkSize = 1200, overlap = 150) {
    const normalized = normalizeText(text);
    if (!normalized) {
        return [];
    }
    const chunks = [];
    let start = 0;
    while (start < normalized.length) {
        const end = Math.min(start + chunkSize, normalized.length);
        chunks.push(normalized.slice(start, end));
        if (end === normalized.length) {
            break;
        }
        start = Math.max(0, end - overlap);
    }
    return chunks;
}
function estimateTokens(text) {
    return Math.max(1, Math.ceil(normalizeText(text).length / 4));
}
function tokenize(text) {
    return normalizeText(text).toLowerCase().split(/[^a-z0-9]+/g).filter(Boolean);
}
