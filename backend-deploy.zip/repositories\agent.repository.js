"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.AgentRepository = void 0;
class AgentRepository {
    agents = new Map();
    save(agent) {
        this.agents.set(agent.id, agent);
        return agent;
    }
    findById(id) {
        return this.agents.get(id);
    }
    listByTenant(tenantId) {
        return Array.from(this.agents.values()).filter((agent) => agent.tenantId === tenantId);
    }
    delete(id) {
        return this.agents.delete(id);
    }
}
exports.AgentRepository = AgentRepository;
