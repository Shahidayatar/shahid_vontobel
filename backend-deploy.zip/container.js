"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createContainer = createContainer;
const agent_repository_1 = require("./repositories/agent.repository");
const document_repository_1 = require("./repositories/document.repository");
const prompt_repository_1 = require("./repositories/prompt.repository");
const provisioning_repository_1 = require("./repositories/provisioning.repository");
const usage_repository_1 = require("./repositories/usage.repository");
const azure_clients_1 = require("./azure/azure-clients");
const agent_service_1 = require("./services/agent-service/agent.service");
const chat_service_1 = require("./services/chat-service/chat.service");
const evaluation_service_1 = require("./services/evaluation-service/evaluation.service");
const provisioning_service_1 = require("./services/provisioning-service/provisioning.service");
const prompt_service_1 = require("./services/prompt-service/prompt.service");
const rag_service_1 = require("./services/rag-service/rag.service");
const usage_service_1 = require("./services/usage-service/usage.service");
function createContainer() {
    const azureClients = (0, azure_clients_1.createAzureClients)();
    const agentRepository = new agent_repository_1.AgentRepository();
    const documentRepository = new document_repository_1.DocumentRepository();
    const promptRepository = new prompt_repository_1.PromptRepository();
    const usageRepository = new usage_repository_1.UsageRepository();
    const provisioningRepository = new provisioning_repository_1.ProvisioningRepository();
    const agentService = new agent_service_1.AgentService(agentRepository, promptRepository);
    const provisioningService = new provisioning_service_1.ProvisioningService(agentRepository, provisioningRepository, azureClients, agentService);
    const ragService = new rag_service_1.RagService(agentRepository, documentRepository, usageRepository, azureClients);
    const chatService = new chat_service_1.ChatService(agentRepository, documentRepository, promptRepository, usageRepository, azureClients);
    const promptService = new prompt_service_1.PromptService(agentRepository, promptRepository);
    const evaluationService = new evaluation_service_1.EvaluationService();
    const usageService = new usage_service_1.UsageService(usageRepository);
    return {
        agentRepository,
        documentRepository,
        promptRepository,
        usageRepository,
        provisioningRepository,
        azureClients,
        agentService,
        provisioningService,
        ragService,
        chatService,
        promptService,
        evaluationService,
        usageService
    };
}
