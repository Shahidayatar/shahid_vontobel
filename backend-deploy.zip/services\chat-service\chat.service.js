"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ChatService = void 0;
const crypto_1 = require("crypto");
const embeddings_1 = require("../shared/embeddings");
const chat_completion_1 = require("../shared/chat-completion");
const text_1 = require("../shared/text");
const vector_search_1 = require("../shared/vector-search");
class ChatService {
    agentRepository;
    documentRepository;
    promptRepository;
    usageRepository;
    azureClients;
    constructor(agentRepository, documentRepository, promptRepository, usageRepository, azureClients) {
        this.agentRepository = agentRepository;
        this.documentRepository = documentRepository;
        this.promptRepository = promptRepository;
        this.usageRepository = usageRepository;
        this.azureClients = azureClients;
    }
    async chat(request) {
        const agent = this.agentRepository.findById(request.agentId);
        if (!agent || agent.tenantId !== request.tenantId) {
            throw new Error("Agent not found for tenant");
        }
        const prompt = this.promptRepository.findActiveByAgent(agent.id, agent.tenantId) ?? {
            id: (0, crypto_1.randomUUID)(),
            agentId: agent.id,
            tenantId: agent.tenantId,
            version: 0,
            systemPrompt: agent.systemPrompt,
            createdBy: "system",
            createdAt: new Date().toISOString(),
            isActive: true
        };
        const queryVector = await this.createVector(request.question);
        const ranked = await this.retrieveContext(agent.id, agent.tenantId, request.question, queryVector);
        const completion = await this.generateAnswer({
            agentName: agent.name,
            model: agent.model,
            systemPrompt: prompt.systemPrompt,
            question: request.question,
            contexts: ranked.map((chunk) => ({ fileName: chunk.fileName, text: chunk.text, score: chunk.score }))
        });
        const estimatedCostUsd = Number((((completion.inputTokens + completion.outputTokens) / 1000) * 0.01).toFixed(6));
        const usageRecord = this.usageRepository.save({
            id: (0, crypto_1.randomUUID)(),
            requestId: (0, crypto_1.randomUUID)(),
            tenantId: request.tenantId,
            agentId: request.agentId,
            operation: "chat",
            model: agent.model,
            inputTokens: completion.inputTokens,
            outputTokens: completion.outputTokens,
            estimatedCostUsd,
            createdAt: new Date().toISOString()
        });
        return {
            answer: completion.answer,
            agentId: agent.id,
            tenantId: agent.tenantId,
            model: agent.model,
            contexts: ranked,
            usage: usageRecord,
            requestId: usageRecord.requestId,
            estimatedTokens: (0, text_1.estimateTokens)(request.question)
        };
    }
    async retrieveContext(agentId, tenantId, question, queryVector) {
        const agent = this.agentRepository.findById(agentId);
        const indexName = agent?.resourcePlan?.searchIndexName ?? `${agentId.slice(0, 12)}-chunks`;
        if (this.azureClients?.search) {
            try {
                const searchClient = this.azureClients.search.getSearchClient(indexName);
                const results = await searchClient.search(question, {
                    filter: `tenantId eq '${tenantId}' and agentId eq '${agentId}'`,
                    top: 5,
                    vectorQueries: [
                        {
                            kind: "vector",
                            fields: ["contentVector"],
                            vector: queryVector,
                            kNearestNeighborsCount: 5
                        }
                    ]
                });
                const ranked = [];
                for await (const result of results.results) {
                    const doc = result.document ?? result;
                    ranked.push({
                        fileName: String(doc.fileName ?? "source"),
                        text: String(doc.content ?? doc.text ?? ""),
                        score: typeof result.score === "number" ? result.score : 0
                    });
                }
                if (ranked.length > 0) {
                    return ranked;
                }
            }
            catch {
                // Fall back to the in-memory store if search is unavailable or the index is not ready.
            }
        }
        const chunks = this.documentRepository.listChunksByAgent(agentId, tenantId);
        return (0, vector_search_1.rankChunks)(chunks, queryVector, 5).map((chunk) => ({
            fileName: chunk.fileName,
            text: chunk.text,
            score: chunk.score
        }));
    }
    async generateAnswer(input) {
        if (this.azureClients?.openAi) {
            const openAiClient = await this.azureClients.openAi.getClient();
            const messages = [
                { role: "system", content: input.systemPrompt },
                {
                    role: "user",
                    content: [
                        `You are ${input.agentName}. Answer the user using only the supplied context.`,
                        `Question: ${input.question}`,
                        `Context:\n${input.contexts.map((context) => `- ${context.fileName}: ${context.text}`).join("\n\n")}`
                    ].join("\n\n")
                }
            ];
            const response = await openAiClient.getChatCompletions(this.azureClients.openAi.chatDeployment, messages, {
                temperature: 0.2,
                maxTokens: 800
            });
            const answer = String(response.choices?.[0]?.message?.content ?? "").trim();
            const usage = response.usage ?? {};
            return {
                answer: answer || (0, chat_completion_1.generateLocalCompletion)(input).answer,
                inputTokens: Number(usage.promptTokens ?? (0, text_1.estimateTokens)(input.systemPrompt + input.question)),
                outputTokens: Number(usage.completionTokens ?? (0, text_1.estimateTokens)(answer))
            };
        }
        return (0, chat_completion_1.generateLocalCompletion)(input);
    }
    async createVector(text) {
        if (this.azureClients?.openAi) {
            const openAiClient = await this.azureClients.openAi.getClient();
            const response = await openAiClient.getEmbeddings(this.azureClients.openAi.embeddingDeployment, [text]);
            return response.data[0]?.embedding;
        }
        return (0, embeddings_1.createEmbedding)(text);
    }
}
exports.ChatService = ChatService;
