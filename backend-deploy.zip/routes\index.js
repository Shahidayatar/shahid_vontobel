"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.registerRoutes = registerRoutes;
const agent_routes_1 = require("./agent.routes");
const chat_routes_1 = require("./chat.routes");
const evaluation_routes_1 = require("./evaluation.routes");
const prompt_routes_1 = require("./prompt.routes");
const provisioning_routes_1 = require("./provisioning.routes");
const rag_routes_1 = require("./rag.routes");
const usage_routes_1 = require("./usage.routes");
function registerRoutes(app, container) {
    app.use((0, agent_routes_1.createAgentRoutes)(container));
    app.use((0, rag_routes_1.createRagRoutes)(container));
    app.use((0, chat_routes_1.createChatRoutes)(container));
    app.use((0, prompt_routes_1.createPromptRoutes)(container));
    app.use((0, provisioning_routes_1.createProvisioningRoutes)(container));
    app.use((0, evaluation_routes_1.createEvaluationRoutes)(container));
    app.use((0, usage_routes_1.createUsageRoutes)(container));
}
