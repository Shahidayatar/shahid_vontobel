"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAgentRoutes = createAgentRoutes;
const express_1 = require("express");
const agent_controller_1 = require("../controllers/agent.controller");
function createAgentRoutes(container) {
    const router = (0, express_1.Router)();
    const controller = (0, agent_controller_1.createAgentController)(container);
    router.post("/agents", controller.createAgent);
    router.get("/agents", controller.listAgents);
    router.get("/agents/:id", controller.getAgent);
    return router;
}
