"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createPromptRoutes = createPromptRoutes;
const express_1 = require("express");
const prompt_controller_1 = require("../controllers/prompt.controller");
function createPromptRoutes(container) {
    const router = (0, express_1.Router)();
    const controller = (0, prompt_controller_1.createPromptController)(container);
    router.post("/prompts", controller.createPrompt);
    router.get("/prompts/:agentId", controller.listPrompts);
    return router;
}
