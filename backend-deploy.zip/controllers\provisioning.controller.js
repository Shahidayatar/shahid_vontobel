"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createProvisioningController = createProvisioningController;
function createProvisioningController(container) {
    return {
        provision: async (req, res) => {
            const tenantId = req.auth?.tenantId ?? req.body.tenantId;
            const agentId = String(req.params.agentId);
            if (!tenantId) {
                return res.status(400).json({ error: "tenantId is required" });
            }
            const status = await container.provisioningService.provisionAgent(agentId, tenantId);
            return res.status(202).json(status);
        },
        getStatus: (req, res) => {
            const status = container.provisioningService.getStatus(String(req.params.agentId));
            if (!status) {
                return res.status(404).json({ error: "Provisioning status not found" });
            }
            return res.json(status);
        }
    };
}
