"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.rankChunks = rankChunks;
function cosineSimilarity(left, right) {
    const length = Math.min(left.length, right.length);
    let dot = 0;
    let leftMagnitude = 0;
    let rightMagnitude = 0;
    for (let index = 0; index < length; index += 1) {
        dot += left[index] * right[index];
        leftMagnitude += left[index] * left[index];
        rightMagnitude += right[index] * right[index];
    }
    if (leftMagnitude === 0 || rightMagnitude === 0) {
        return 0;
    }
    return dot / (Math.sqrt(leftMagnitude) * Math.sqrt(rightMagnitude));
}
function rankChunks(chunks, queryVector, topK = 5) {
    return chunks
        .map((chunk) => ({ ...chunk, score: cosineSimilarity(chunk.vector, queryVector) }))
        .sort((left, right) => right.score - left.score)
        .slice(0, topK);
}
