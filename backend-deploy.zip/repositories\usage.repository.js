"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.UsageRepository = void 0;
class UsageRepository {
    records = new Map();
    save(record) {
        this.records.set(record.id, record);
        return record;
    }
    listByTenant(tenantId) {
        return Array.from(this.records.values()).filter((record) => record.tenantId === tenantId);
    }
    listByAgent(agentId) {
        return Array.from(this.records.values()).filter((record) => record.agentId === agentId);
    }
}
exports.UsageRepository = UsageRepository;
