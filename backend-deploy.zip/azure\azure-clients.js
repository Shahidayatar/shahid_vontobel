"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createAzureClients = createAzureClients;
const identity_1 = require("@azure/identity");
const storage_blob_1 = require("@azure/storage-blob");
const search_documents_1 = require("@azure/search-documents");
const keyvault_secrets_1 = require("@azure/keyvault-secrets");
const env_1 = require("../config/env");
function createCredential() {
    return new identity_1.DefaultAzureCredential();
}
function createSearchIndex(indexName, dimensions) {
    return {
        name: indexName,
        fields: [
            { name: "id", type: "Edm.String", key: true, searchable: false, filterable: true, sortable: false, facetable: false },
            { name: "tenantId", type: "Edm.String", searchable: false, filterable: true, sortable: false, facetable: true },
            { name: "agentId", type: "Edm.String", searchable: false, filterable: true, sortable: false, facetable: true },
            { name: "documentId", type: "Edm.String", searchable: false, filterable: true, sortable: false, facetable: false },
            { name: "fileName", type: "Edm.String", searchable: true, filterable: true, sortable: true, facetable: false },
            { name: "chunkIndex", type: "Edm.Int32", searchable: false, filterable: true, sortable: true, facetable: false },
            { name: "content", type: "Edm.String", searchable: true, filterable: false, sortable: false, facetable: false },
            {
                name: "contentVector",
                type: "Collection(Edm.Single)",
                searchable: true,
                filterable: false,
                sortable: false,
                facetable: false,
                vectorSearchDimensions: dimensions,
                vectorSearchProfileName: "vector-profile"
            }
        ],
        vectorSearch: {
            algorithms: [
                {
                    name: "vector-hnsw",
                    kind: "hnsw",
                    hnswParameters: {
                        metric: "cosine"
                    }
                }
            ],
            profiles: [
                {
                    name: "vector-profile",
                    algorithmConfigurationName: "vector-hnsw"
                }
            ]
        }
    };
}
function createAzureClients() {
    const credential = createCredential();
    const openAi = env_1.env.AZURE_OPENAI_ENDPOINT && env_1.env.AZURE_OPENAI_CHAT_DEPLOYMENT && env_1.env.AZURE_OPENAI_EMBEDDING_DEPLOYMENT
        ? {
            async getClient() {
                const azureOpenAi = await import("@azure/openai");
                return new azureOpenAi.OpenAIClient(env_1.env.AZURE_OPENAI_ENDPOINT, credential);
            },
            chatDeployment: env_1.env.AZURE_OPENAI_CHAT_DEPLOYMENT,
            embeddingDeployment: env_1.env.AZURE_OPENAI_EMBEDDING_DEPLOYMENT
        }
        : undefined;
    const search = env_1.env.AZURE_SEARCH_ENDPOINT
        ? (() => {
            const indexClient = new search_documents_1.SearchIndexClient(env_1.env.AZURE_SEARCH_ENDPOINT, credential);
            return {
                indexClient,
                getSearchClient(indexName) {
                    return new search_documents_1.SearchClient(env_1.env.AZURE_SEARCH_ENDPOINT, indexName, credential);
                },
                async ensureIndex(indexName, dimensions) {
                    try {
                        await indexClient.getIndex(indexName);
                    }
                    catch {
                        await indexClient.createIndex(createSearchIndex(indexName, dimensions));
                    }
                }
            };
        })()
        : undefined;
    const blob = env_1.env.AZURE_BLOB_SERVICE_URL
        ? {
            serviceClient: new storage_blob_1.BlobServiceClient(env_1.env.AZURE_BLOB_SERVICE_URL, credential),
            getContainerClient(containerName) {
                return new storage_blob_1.BlobServiceClient(env_1.env.AZURE_BLOB_SERVICE_URL, credential).getContainerClient(containerName);
            },
            async ensureContainer(containerName) {
                const containerClient = new storage_blob_1.BlobServiceClient(env_1.env.AZURE_BLOB_SERVICE_URL, credential).getContainerClient(containerName);
                await containerClient.createIfNotExists();
                return containerClient;
            }
        }
        : undefined;
    const keyVault = env_1.env.AZURE_KEY_VAULT_URL
        ? {
            client: new keyvault_secrets_1.SecretClient(env_1.env.AZURE_KEY_VAULT_URL, credential),
            async setSecret(name, value) {
                await new keyvault_secrets_1.SecretClient(env_1.env.AZURE_KEY_VAULT_URL, credential).setSecret(name, value);
            }
        }
        : undefined;
    return {
        openAi,
        search,
        blob,
        keyVault
    };
}
