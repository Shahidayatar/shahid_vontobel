"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.createProvisioningRoutes = createProvisioningRoutes;
const express_1 = require("express");
const provisioning_controller_1 = require("../controllers/provisioning.controller");
function createProvisioningRoutes(container) {
    const router = (0, express_1.Router)();
    const controller = (0, provisioning_controller_1.createProvisioningController)(container);
    router.post("/provision/:agentId", controller.provision);
    router.get("/provision/status/:agentId", controller.getStatus);
    return router;
}
