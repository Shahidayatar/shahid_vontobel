"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.env = void 0;
const dotenv_1 = require("dotenv");
const zod_1 = require("zod");
(0, dotenv_1.config)();
const envSchema = zod_1.z.object({
    NODE_ENV: zod_1.z.enum(["development", "test", "production"]).default("development"),
    PORT: zod_1.z.coerce.number().default(8080),
    AUTH_DISABLED: zod_1.z.coerce.boolean().default(true),
    AZURE_USE_MANAGED_IDENTITY: zod_1.z.coerce.boolean().default(true),
    AZURE_AD_TENANT_ID: zod_1.z.string().optional(),
    AZURE_AD_CLIENT_ID: zod_1.z.string().optional(),
    AZURE_AD_ISSUER: zod_1.z.string().optional(),
    AZURE_AD_JWKS_URI: zod_1.z.string().optional(),
    AZURE_OPENAI_ENDPOINT: zod_1.z.string().optional(),
    AZURE_OPENAI_CHAT_DEPLOYMENT: zod_1.z.string().optional(),
    AZURE_OPENAI_EMBEDDING_DEPLOYMENT: zod_1.z.string().optional(),
    AZURE_SEARCH_ENDPOINT: zod_1.z.string().optional(),
    AZURE_SEARCH_INDEX_PREFIX: zod_1.z.string().default("aifoundry"),
    AZURE_BLOB_SERVICE_URL: zod_1.z.string().optional(),
    AZURE_BLOB_CONTAINER_PREFIX: zod_1.z.string().default("agentdocs"),
    AZURE_KEY_VAULT_URL: zod_1.z.string().optional(),
    EMBEDDING_DIMENSIONS: zod_1.z.coerce.number().default(1536),
    APP_NAME: zod_1.z.string().default("ai-foundry-as-a-service")
});
exports.env = envSchema.parse(process.env);
