"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.requestContextMiddleware = requestContextMiddleware;
const crypto_1 = require("crypto");
function requestContextMiddleware(req, res, next) {
    const requestId = req.header("x-request-id") ?? (0, crypto_1.randomUUID)();
    req.requestId = requestId;
    res.setHeader("x-request-id", requestId);
    next();
}
