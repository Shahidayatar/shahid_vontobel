"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.authMiddleware = authMiddleware;
const jose_1 = require("jose");
const env_1 = require("../config/env");
const logger_1 = require("../config/logger");
function buildDevAuth(req) {
    const tenantId = req.header("x-tenant-id") ?? "tenant-dev";
    const userId = req.header("x-user-id") ?? "user-dev";
    const roles = (req.header("x-user-roles") ?? "PlatformAdmin").split(",").map((role) => role.trim()).filter(Boolean);
    return {
        tenantId,
        userId,
        roles
    };
}
async function verifyBearerToken(token) {
    const jwksUri = env_1.env.AZURE_AD_JWKS_URI;
    const issuer = env_1.env.AZURE_AD_ISSUER;
    const audience = env_1.env.AZURE_AD_CLIENT_ID;
    if (!jwksUri || !issuer || !audience) {
        throw new Error("Azure Entra configuration is incomplete");
    }
    const jwks = (0, jose_1.createRemoteJWKSet)(new URL(jwksUri));
    const result = await (0, jose_1.jwtVerify)(token, jwks, { issuer, audience });
    const payload = result.payload;
    const tenantId = typeof payload.tid === "string" ? payload.tid : "unknown-tenant";
    const userId = typeof payload.oid === "string" ? payload.oid : typeof payload.sub === "string" ? payload.sub : "unknown-user";
    const roles = Array.isArray(payload.roles)
        ? payload.roles.filter((role) => typeof role === "string")
        : [];
    return {
        tenantId,
        userId,
        roles,
        issuer: typeof payload.iss === "string" ? payload.iss : undefined,
        tokenSubject: typeof payload.sub === "string" ? payload.sub : undefined
    };
}
async function authMiddleware(req, res, next) {
    if (env_1.env.AUTH_DISABLED) {
        req.auth = buildDevAuth(req);
        return next();
    }
    const authorization = req.header("authorization");
    if (!authorization?.startsWith("Bearer ")) {
        return res.status(401).json({ error: "Unauthorized", message: "Missing bearer token" });
    }
    try {
        req.auth = await verifyBearerToken(authorization.slice(7));
        return next();
    }
    catch (error) {
        logger_1.logger.warn("Authentication failed", {
            requestId: req.requestId,
            error: error instanceof Error ? error.message : String(error)
        });
        return res.status(401).json({ error: "Unauthorized", message: "Invalid token" });
    }
}
