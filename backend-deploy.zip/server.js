"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const env_1 = require("./config/env");
const logger_1 = require("./config/logger");
const app_1 = require("./app");
const app = (0, app_1.buildApp)();
app.listen(env_1.env.PORT, () => {
    logger_1.logger.info("Backend server started", { port: env_1.env.PORT });
});
