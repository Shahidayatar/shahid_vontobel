"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.EvaluationService = void 0;
const text_1 = require("../shared/text");
class EvaluationService {
    evaluate(request) {
        const answerTokens = (0, text_1.tokenize)(request.answer);
        const contextTokens = new Set((0, text_1.tokenize)(request.context));
        const supported = answerTokens.filter((token) => contextTokens.has(token)).length;
        const supportRatio = answerTokens.length === 0 ? 0 : supported / answerTokens.length;
        const hallucinationRisk = Number((1 - supportRatio).toFixed(3));
        const qualityScore = Number((Math.min(1, supportRatio + (request.expectedAnswer ? 0.2 : 0)) * 100).toFixed(1));
        return {
            hallucinationRisk,
            qualityScore,
            passed: hallucinationRisk < 0.45 && qualityScore >= 55,
            notes: [
                supportRatio >= 0.4 ? "Context support is acceptable." : "Answer may be under-grounded.",
                request.expectedAnswer ? "Reference answer provided for regression scoring." : "No reference answer provided."
            ]
        };
    }
}
exports.EvaluationService = EvaluationService;
