"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ProvisioningService = void 0;
const crypto_1 = require("crypto");
const logger_1 = require("../../config/logger");
class ProvisioningService {
    agentRepository;
    provisioningRepository;
    azureClients;
    agentService;
    constructor(agentRepository, provisioningRepository, azureClients, agentService) {
        this.agentRepository = agentRepository;
        this.provisioningRepository = provisioningRepository;
        this.azureClients = azureClients;
        this.agentService = agentService;
    }
    async provisionAgent(agentId, tenantId) {
        const agent = this.agentRepository.findById(agentId);
        if (!agent || agent.tenantId !== tenantId) {
            throw new Error("Agent not found for tenant");
        }
        const resourcePlan = {
            openAIDeploymentName: `aoai-${tenantId.slice(0, 8)}-${agentId.slice(0, 8)}`,
            searchIndexName: `idx-${agentId.slice(0, 12)}`,
            storageContainerName: `docs-${agentId.slice(0, 12)}`,
            keyVaultSecretNames: ["aoai-key", "search-key", "storage-connection-string"],
            managedIdentityName: `mi-${agentId.slice(0, 12)}`
        };
        const queued = this.updateStatus(agentId, tenantId, "queued", "Queued for provisioning", ["Resource plan generated"]);
        logger_1.logger.info("Provisioning queued", { agentId, tenantId, requestId: (0, crypto_1.randomUUID)() });
        const running = this.updateStatus(agentId, tenantId, "running", "Creating resources", ["Azure OpenAI deployment", "AI Search index", "Blob container", "Key Vault secret plan", "Managed identity"]);
        await Promise.resolve(running);
        const completed = this.updateStatus(agentId, tenantId, "succeeded", "Provisioning complete", ["Resources planned locally. Replace with Terraform or Azure SDK calls for live deployment."]);
        if (this.azureClients?.search) {
            await this.azureClients.search.ensureIndex(resourcePlan.searchIndexName, 1536);
        }
        if (this.azureClients?.blob) {
            await this.azureClients.blob.ensureContainer(resourcePlan.storageContainerName);
        }
        if (this.azureClients?.keyVault) {
            await this.azureClients.keyVault.setSecret(`${agentId}-resource-plan`, JSON.stringify(resourcePlan));
        }
        if (this.agentService) {
            this.agentService.markProvisioned(agentId, resourcePlan, completed.state);
        }
        return completed;
    }
    getStatus(agentId) {
        return this.provisioningRepository.findByAgentId(agentId);
    }
    updateStatus(agentId, tenantId, state, currentStep, messages) {
        const status = {
            agentId,
            tenantId,
            state,
            currentStep,
            messages,
            updatedAt: new Date().toISOString()
        };
        this.provisioningRepository.save(status);
        return status;
    }
}
exports.ProvisioningService = ProvisioningService;
