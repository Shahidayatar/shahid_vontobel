"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.generateLocalCompletion = generateLocalCompletion;
const text_1 = require("./text");
function summarizeContext(contexts) {
    if (contexts.length === 0) {
        return "No relevant source documents were found for this query.";
    }
    return contexts
        .slice(0, 3)
        .map((context, index) => `Source ${index + 1} (${context.fileName}, score ${context.score.toFixed(3)}): ${context.text.slice(0, 450)}`)
        .join("\n\n");
}
function generateLocalCompletion(input) {
    const contextSummary = summarizeContext(input.contexts);
    const groundedTokens = (0, text_1.tokenize)(contextSummary).length;
    const answer = [
        `Agent ${input.agentName} response`,
        `System prompt: ${input.systemPrompt}`,
        `Question: ${input.question}`,
        `Grounded context: ${contextSummary}`,
        groundedTokens > 0
            ? "Answer: I used the retrieved context to produce this response and can cite the source documents if needed."
            : "Answer: I did not find supporting context, so this response is a best-effort summary and should be reviewed before reuse."
    ].join("\n\n");
    return {
        answer,
        inputTokens: (0, text_1.estimateTokens)(`${input.systemPrompt}\n${input.question}\n${contextSummary}`),
        outputTokens: (0, text_1.estimateTokens)(answer)
    };
}
